declare namespace Cloudflare {
  interface Env {
    GA_CLIENT_SECRET: string;
    GA_REFRESH_TOKEN: string;
    SUPABASE_SERVICE_ROLE_KEY: string;
    RESEND_API_KEY: string;
    RESEND_WEBHOOK_SECRET: string;
    CLOUDINARY_CLOUD_NAME: string;
    CLOUDINARY_API_KEY: string;
    CLOUDINARY_API_SECRET: string;
  }
}
